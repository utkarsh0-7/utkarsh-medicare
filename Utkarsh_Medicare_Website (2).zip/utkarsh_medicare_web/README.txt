UTKARSH MEDICARE - WEB EDITION
==============================
A Java Spring Boot + Thymeleaf + MySQL web application.

REQUIREMENTS
------------
1. JDK 17 or newer
2. Apache Maven 3.8+
3. MySQL Server running
4. Existing database: hospital_db

DATABASE
--------
This web app uses the same table names and columns as the desktop project:
- patients(patient_id, name, age, gender, phone, address)
- doctors(doctor_id, name, specialization, phone)
- appointments(appointment_id, patient_id, doctor_id, appointment_date)
- billing(bill_id, patient_id, amount, payment_status)

It does not recreate or delete your existing data. Make a database backup before testing.

CONFIGURE DATABASE LOGIN
-------------------------
Open src/main/resources/application.properties.
The defaults are:
  URL: jdbc:mysql://localhost:3306/hospital_db
  USER: root
  PASSWORD: (blank)

If your MySQL root account has a password, set it using an environment variable before starting.
Windows PowerShell:
  $env:DB_PASSWORD="your_mysql_password"
  $env:DB_USER="root"
  mvn spring-boot:run

You can also edit application.properties and replace the blank DB_PASSWORD default,
but environment variables are safer than storing a password in the project.

RUN IN VS CODE
--------------
1. Extract this ZIP.
2. Open the extracted utkarsh_medicare_web folder in VS Code.
3. Install the "Extension Pack for Java" and "Spring Boot Extension Pack" if needed.
4. Open the VS Code terminal in the project folder.
5. Configure DB_PASSWORD if your MySQL server requires it (see above).
6. Run: mvn spring-boot:run
7. Wait until Spring Boot says it has started.
8. Open http://localhost:8080 in your browser.

LOGIN
-----
Username: admin
Password: 1234

FEATURES
--------
- Responsive sign-in screen and modern hospital dashboard
- Patient records: add, list, search, delete
- Doctor records: add, list, search, delete
- Appointments: book, list, search, cancel
- Patient and doctor dropdowns are loaded from MySQL. The selected database IDs
  are inserted into the appointment, not a hard-coded patient ID of 1.
- Billing: create bills, mark paid, delete, search
- Dashboard: counts, monthly appointment graph, collected revenue and pending amount
- Total revenue counts bills whose payment_status is Paid (case-insensitive).

IMPORTANT
---------
The demo login is for a local college project only. Before real deployment, add
proper user accounts, password hashing, role-based access, CSRF protection,
HTTPS, backups and production security controls. Do not expose this demo app
or your database directly to the public internet.
