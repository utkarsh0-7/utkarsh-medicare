package com.utkarsh.medicare;

import jakarta.servlet.http.HttpSession;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Controller
public class WebController {
  private final JdbcTemplate db;
  public WebController(JdbcTemplate db) { this.db = db; }
  private boolean logged(HttpSession s) { return s.getAttribute("user") != null; }
  private String guard(HttpSession s) { return logged(s) ? null : "redirect:/login"; }
  @GetMapping("/") public String root(HttpSession s) { return logged(s) ? "redirect:/dashboard" : "redirect:/login"; }
  @GetMapping("/login") public String loginPage() { return "login"; }
  @PostMapping("/login") public String login(@RequestParam String username, @RequestParam String password, HttpSession s, RedirectAttributes ra) {
    if ("admin".equals(username) && "1234".equals(password)) { s.setAttribute("user", username); return "redirect:/dashboard"; }
    ra.addFlashAttribute("error", "Incorrect username or password."); return "redirect:/login";
  }
  @GetMapping("/logout") public String logout(HttpSession s) { s.invalidate(); return "redirect:/login"; }

  @GetMapping("/dashboard") public String dashboard(HttpSession s, Model m) {
    if (!logged(s)) return "redirect:/login";
    m.addAttribute("active", "dashboard");
    m.addAttribute("patients", count("patients")); m.addAttribute("doctors", count("doctors"));
    m.addAttribute("appointments", count("appointments")); m.addAttribute("bills", count("billing"));
    m.addAttribute("revenue", scalar("SELECT COALESCE(SUM(amount),0) FROM billing WHERE LOWER(payment_status)='paid'"));
    m.addAttribute("pending", scalar("SELECT COALESCE(SUM(amount),0) FROM billing WHERE LOWER(payment_status)<>'paid'"));
    m.addAttribute("recent", db.queryForList("SELECT a.appointment_id,a.appointment_date,p.name patient_name,d.name doctor_name FROM appointments a LEFT JOIN patients p ON a.patient_id=p.patient_id LEFT JOIN doctors d ON a.doctor_id=d.doctor_id ORDER BY a.appointment_date DESC LIMIT 6"));
    List<Integer> months = new ArrayList<>(); List<String> monthLabels = new ArrayList<>();
    for (int i=5;i>=0;i--) { LocalDate date=LocalDate.now().minusMonths(i); Integer n=db.queryForObject("SELECT COUNT(*) FROM appointments WHERE YEAR(appointment_date)=? AND MONTH(appointment_date)=?", Integer.class,date.getYear(),date.getMonthValue()); months.add(n==null?0:n); monthLabels.add(date.getMonth().getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH)); }
    m.addAttribute("monthCounts", months); m.addAttribute("monthLabels", monthLabels); return "dashboard";
  }
  private int count(String table) { Integer n=db.queryForObject("SELECT COUNT(*) FROM "+table,Integer.class); return n==null?0:n; }
  private BigDecimal scalar(String sql) { BigDecimal n=db.queryForObject(sql,BigDecimal.class); return n==null?BigDecimal.ZERO:n; }

  @GetMapping("/patients") public String patients(HttpSession s, Model m) { if(!logged(s))return "redirect:/login"; m.addAttribute("active","patients"); m.addAttribute("rows",db.queryForList("SELECT * FROM patients ORDER BY patient_id DESC")); return "patients"; }
  @PostMapping("/patients/save") public String savePatient(@RequestParam(required=false) Integer patientId,@RequestParam String name,@RequestParam int age,@RequestParam String gender,@RequestParam String phone,@RequestParam(defaultValue="") String address,HttpSession s,RedirectAttributes ra) {
    if(!logged(s))return "redirect:/login";
    if(patientId==null) db.update("INSERT INTO patients(name,age,gender,phone,address) VALUES(?,?,?,?,?)",name,age,gender,phone,address);
    else db.update("UPDATE patients SET name=?,age=?,gender=?,phone=?,address=? WHERE patient_id=?",name,age,gender,phone,address,patientId);
    ra.addFlashAttribute("success","Patient saved successfully."); return "redirect:/patients";
  }
  @PostMapping("/patients/delete/{id}") public String deletePatient(@PathVariable int id,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; try { db.update("DELETE FROM patients WHERE patient_id=?",id); ra.addFlashAttribute("success","Patient deleted."); } catch(Exception e) { ra.addFlashAttribute("error","Cannot delete: this patient is linked to an appointment or bill."); } return "redirect:/patients"; }

  @GetMapping("/doctors") public String doctors(HttpSession s,Model m) { if(!logged(s))return "redirect:/login"; m.addAttribute("active","doctors"); m.addAttribute("rows",db.queryForList("SELECT * FROM doctors ORDER BY doctor_id DESC")); return "doctors"; }
  @PostMapping("/doctors/save") public String saveDoctor(@RequestParam(required=false) Integer doctorId,@RequestParam String name,@RequestParam String specialization,@RequestParam String phone,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; if(doctorId==null)db.update("INSERT INTO doctors(name,specialization,phone) VALUES(?,?,?)",name,specialization,phone); else db.update("UPDATE doctors SET name=?,specialization=?,phone=? WHERE doctor_id=?",name,specialization,phone,doctorId); ra.addFlashAttribute("success","Doctor saved successfully."); return "redirect:/doctors"; }
  @PostMapping("/doctors/delete/{id}") public String deleteDoctor(@PathVariable int id,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; try{db.update("DELETE FROM doctors WHERE doctor_id=?",id);ra.addFlashAttribute("success","Doctor deleted.");}catch(Exception e){ra.addFlashAttribute("error","Cannot delete: this doctor is linked to an appointment.");}return "redirect:/doctors"; }

  @GetMapping("/appointments") public String appointments(HttpSession s,Model m) { if(!logged(s))return "redirect:/login"; m.addAttribute("active","appointments"); m.addAttribute("rows",db.queryForList("SELECT a.appointment_id,a.patient_id,a.doctor_id,a.appointment_date,p.name patient_name,d.name doctor_name FROM appointments a LEFT JOIN patients p ON a.patient_id=p.patient_id LEFT JOIN doctors d ON a.doctor_id=d.doctor_id ORDER BY a.appointment_date DESC")); m.addAttribute("patients",db.queryForList("SELECT patient_id,name,phone FROM patients ORDER BY name")); m.addAttribute("doctors",db.queryForList("SELECT doctor_id,name,specialization FROM doctors ORDER BY name")); return "appointments"; }
  @PostMapping("/appointments/save") public String saveAppointment(@RequestParam int patientId,@RequestParam int doctorId,@RequestParam String appointmentDate,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; try { db.update("INSERT INTO appointments(patient_id,doctor_id,appointment_date) VALUES(?,?,?)",patientId,doctorId,LocalDate.parse(appointmentDate)); ra.addFlashAttribute("success","Appointment booked."); }catch(Exception e){ra.addFlashAttribute("error","Could not book appointment. Check the selected patient, doctor and date.");}return "redirect:/appointments"; }
  @PostMapping("/appointments/delete/{id}") public String deleteAppointment(@PathVariable int id,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; db.update("DELETE FROM appointments WHERE appointment_id=?",id);ra.addFlashAttribute("success","Appointment cancelled.");return "redirect:/appointments"; }

  @GetMapping("/billing") public String billing(HttpSession s,Model m) { if(!logged(s))return "redirect:/login"; m.addAttribute("active","billing"); m.addAttribute("rows",db.queryForList("SELECT b.bill_id,b.patient_id,p.name patient_name,b.amount,b.payment_status FROM billing b LEFT JOIN patients p ON b.patient_id=p.patient_id ORDER BY b.bill_id DESC")); m.addAttribute("patients",db.queryForList("SELECT patient_id,name FROM patients ORDER BY name")); m.addAttribute("revenue",scalar("SELECT COALESCE(SUM(amount),0) FROM billing WHERE LOWER(payment_status)='paid'")); m.addAttribute("pending",scalar("SELECT COALESCE(SUM(amount),0) FROM billing WHERE LOWER(payment_status)<>'paid'")); return "billing"; }
  @PostMapping("/billing/save") public String saveBill(@RequestParam int patientId,@RequestParam BigDecimal amount,@RequestParam String paymentStatus,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; db.update("INSERT INTO billing(patient_id,amount,payment_status) VALUES(?,?,?)",patientId,amount,paymentStatus);ra.addFlashAttribute("success","Bill created.");return "redirect:/billing"; }
  @PostMapping("/billing/status/{id}") public String paid(@PathVariable int id,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; db.update("UPDATE billing SET payment_status='Paid' WHERE bill_id=?",id);ra.addFlashAttribute("success","Payment marked as paid.");return "redirect:/billing"; }
  @PostMapping("/billing/delete/{id}") public String deleteBill(@PathVariable int id,HttpSession s,RedirectAttributes ra) { if(!logged(s))return "redirect:/login"; db.update("DELETE FROM billing WHERE bill_id=?",id);ra.addFlashAttribute("success","Bill deleted.");return "redirect:/billing"; }
}
