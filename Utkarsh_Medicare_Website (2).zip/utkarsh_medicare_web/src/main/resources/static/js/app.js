document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-search]').forEach(input=>input.addEventListener('input',()=>{
    const table=document.getElementById(input.dataset.search); if(!table)return;
    const q=input.value.toLowerCase(); table.querySelectorAll('tbody tr').forEach(row=>row.style.display=row.innerText.toLowerCase().includes(q)?'':'none');
  }));
  const chart=document.getElementById('appointmentChart');
  if(chart){const bars=[...chart.querySelectorAll('.bar-fill')];const max=Math.max(1,...bars.map(b=>Number(b.dataset.value)||0));bars.forEach(b=>b.style.height=Math.max(4,((Number(b.dataset.value)||0)/max)*100)+'%');}
});
